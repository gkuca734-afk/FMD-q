package com.example.floatingmenudemo

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var overlay: View? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    companion object {
        @Volatile var isRunning: Boolean = false
            private set
    }

    private val panelColor = Color.rgb(25, 33, 52)
    private val white = Color.rgb(245, 247, 255)
    private val muted = Color.rgb(167, 177, 202)
    private val accent = Color.rgb(88, 116, 255)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (overlay == null) createOverlay()
        return START_NOT_STICKY
    }

    private fun rounded(color: Int, radius: Float = 18f) =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun label(value: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun createOverlay() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 16, 18, 16)
            background = rounded(panelColor, 22f)
            elevation = 18f
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(label("Меню запуска", 19f, white, true),
            LinearLayout.LayoutParams(0, -2, 1f))
        val close = label("✕", 22f, muted, true).apply {
            setPadding(12, 4, 2, 4)
            setOnClickListener { stopSelf() }
        }
        header.addView(close)
        root.addView(header)
        root.addView(label("●  Активно поверх экрана", 13f, Color.rgb(105, 224, 164)).apply {
            setPadding(0, 5, 0, 14)
        })

        fun addAction(title: String, description: String, message: String) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(13, 11, 13, 11)
                background = rounded(Color.rgb(36, 46, 70), 14f)
                isClickable = true
                isFocusable = true
                setOnClickListener {
                    Toast.makeText(this@OverlayService, message, Toast.LENGTH_SHORT).show()
                }
            }
            row.addView(label(title, 15f, white, true))
            row.addView(label(description, 12f, muted).apply { setPadding(0, 3, 0, 0) })
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.bottomMargin = 8
            root.addView(row, lp)
        }
        addAction("Запустить", "Демонстрационный пункт меню", "Демо запущено")
        addAction("Настройки", "Пример пункта меню", "Настройки демо")
        addAction("Информация", "Floating Menu Demo · v1.1", "Версия 1.1")

        // Drag the panel by touching the header.
        header.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var touchX = 0f
            private var touchY = 0f
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                val params = layoutParams ?: return false
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        touchX = event.rawX
                        touchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = initialX + (event.rawX - touchX).toInt()
                        params.y = initialY + (event.rawY - touchY).toInt()
                        windowManager.updateViewLayout(root, params)
                        return true
                    }
                }
                return false
            }
        })

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.84f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 100
        }
        layoutParams = params
        windowManager.addView(root, params)
        overlay = root
        isRunning = true
    }

    override fun onDestroy() {
        overlay?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        overlay = null
        isRunning = false
        super.onDestroy()
    }
}
