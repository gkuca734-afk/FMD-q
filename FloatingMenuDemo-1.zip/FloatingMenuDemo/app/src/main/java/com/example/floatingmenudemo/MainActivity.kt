package com.example.floatingmenudemo

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(13, 18, 31)
    private val accent = Color.rgb(88, 116, 255)
    private val white = Color.rgb(245, 247, 255)
    private val muted = Color.rgb(167, 177, 202)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun rounded(color: Int, radius: Float = 22f) =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun button(label: String, color: Int, onClick: () -> Unit) =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 16f
            setTextColor(Color.WHITE)
            background = rounded(color, 18f)
            setPadding(24, 16, 24, 16)
            setOnClickListener { onClick() }
        }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            background = rounded(bg, 0f)
        }
        root.addView(text("FLOATING MENU", 13f, accent, true).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.16f
        })
        root.addView(text("Панель запуска", 30f, white, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 10)
        })
        root.addView(text(
            "Плавающее меню может оставаться поверх других приложений. Для этого Android запросит специальное разрешение.",
            16f, muted
        ).apply {
            gravity = Gravity.CENTER
            setPadding(8, 0, 8, 28)
        })
        root.addView(button("Инжект / Запустить", accent) {
            if (OverlayService.isRunning) {
                stopService(Intent(this, OverlayService::class.java))
                Toast.makeText(this, "Плавающее меню закрыто", Toast.LENGTH_SHORT).show()
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName"))
                startActivity(intent)
                Toast.makeText(this, "Разреши отображение поверх других приложений, затем нажми кнопку ещё раз", Toast.LENGTH_LONG).show()
            } else {
                startService(Intent(this, OverlayService::class.java))
                Toast.makeText(this, "Плавающее меню запущено", Toast.LENGTH_SHORT).show()
            }
        }, LinearLayout.LayoutParams(-1, -2))
        root.addView(text(
            "Повторное нажатие на кнопку останавливает меню.",
            12f, muted
        ).apply { gravity = Gravity.CENTER; setPadding(10, 22, 10, 0) })
        setContentView(root)
    }
}
