# Floating Menu Demo (Android) — v1.1

Android Studio project in Kotlin. The "Инжект / Запустить" button toggles a floating menu rendered with Android's overlay window API. With the user-granted "Display over other apps" permission, it remains visible while switching to other apps.

## Run
1. Unzip the archive and open `FloatingMenuDemo` in Android Studio.
2. Wait for Gradle Sync.
3. Run on an Android device or emulator.
4. Tap **Инжект / Запустить**. If prompted, grant **Display over other apps**, return to the app, and tap the button again.
5. Tap the floating panel's **✕** or return to the app and tap **Инжект / Запустить** again to stop it.

## Behavior and limitations
- This is a visible, user-controlled overlay demo; it does not inject code into other apps.
- Android may stop background services under system restrictions. This sample does not request persistent foreground-service operation.
- Removing the app from Recents is controlled by the Android launcher/system and is not a guaranteed universal signal for stopping a normal service on every device.
